#!/bin/bash

sh "/usr/lib64/nagios/plugins/check_mem.pl -f -w 15 -c 5 -C"
